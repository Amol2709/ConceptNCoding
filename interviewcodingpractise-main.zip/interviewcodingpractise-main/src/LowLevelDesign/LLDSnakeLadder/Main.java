package LowLevelDesign.LLDSnakeLadder;

public class Main {

    public static void main(String args[]) {

        Game obj = new Game();
        obj.startGame();
    }
}
