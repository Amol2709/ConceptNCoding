package LowLevelDesign.LLDCarRentalSystem;

public enum ReservationType {

    HOURLY,
    DAILY;
}
