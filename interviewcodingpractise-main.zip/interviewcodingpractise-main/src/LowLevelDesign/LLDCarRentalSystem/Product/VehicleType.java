package LowLevelDesign.LLDCarRentalSystem.Product;

public enum VehicleType {
    CAR;
}
