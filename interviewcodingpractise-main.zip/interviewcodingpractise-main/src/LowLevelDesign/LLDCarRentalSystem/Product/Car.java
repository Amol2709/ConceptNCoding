package LowLevelDesign.LLDCarRentalSystem.Product;

public class Car extends Vehicle{

}
