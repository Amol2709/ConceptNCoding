package LowLevelDesign.LLDCarRentalSystem;

public enum ReservationStatus {

    SCHEDULED,
    INPROGRESS,
    COMPLETED,
    CANCELLED;
}
