public class testingMethod {

    public static void main(String args[]) {

        int x=-3;
        System.out.println(x/2);
    }
}
